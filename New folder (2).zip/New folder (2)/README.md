# crud-app 
# Advance OOP Tests

A basic full-stack app with Spring Boot backend and React TypeScript frontend.

## Setup
- Backend: Run `mvn spring-boot:run` in /backend
- Frontend: Run `npm start` in /frontend

## Devcontainer
Uses Java 17 and Node 20 for Codespaces.